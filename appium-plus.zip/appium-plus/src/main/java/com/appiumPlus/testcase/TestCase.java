package com.appiumPlus.testcase;

import com.appiumPlus.core.BaseTest;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class TestCase extends BaseTest {
    @Test
    public void testLogin(){
        //点击登录
        engine.click("class=android.widget.TextView" , 0);

        //输入账号
        engine.clearAndType("class=android.widget.EditText" , 0 , "123");
        //输入密码
        engine.clearAndType("class=android.widget.EditText" , 1 , "123");
        //点击登录
        engine.click("class=android.widget.TextView" , 4);

    }
}
