package com.appiumPlus.po;

import lombok.Data;

/**
 * 入口页面
 */
@Data
public class EntrancePage {
    //登录按钮的class和在数组中的下标
    private String loginButtonClassName = "android.widget.TextView";
    private int loginButtonIndex = 0;

    //注册按钮的class和在数组中的下标
    private String signinButtonClassName = "android.widget.TextView";
    private int signinButtonIndex = 1;
}
